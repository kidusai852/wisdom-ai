import React from 'react';
import { 
  Sparkles, 
  Atom, 
  Calculator, 
  Globe, 
  Code, 
  BookOpen, 
  Compass, 
  ArrowRight,
  CheckCircle2,
  Layers,
  HelpCircle,
  Zap
} from 'lucide-react';
import { StudyMode } from '../types.ts';

interface EmptyStateProps {
  onSelectPrompt: (prompt: string, mode?: StudyMode) => void;
}

interface SubjectCard {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgLight: string;
  borderLight: string;
  prompt: string;
  mode: StudyMode;
}

const STARTER_SUBJECTS: SubjectCard[] = [
  {
    title: 'Biology & Science',
    icon: Atom,
    color: 'text-emerald-600',
    bgLight: 'bg-emerald-50',
    borderLight: 'border-emerald-200/60',
    prompt: 'Explain Photosynthesis step-by-step using a kitchen or factory analogy.',
    mode: 'breakdown',
  },
  {
    title: 'Math & Algebra',
    icon: Calculator,
    color: 'text-blue-600',
    bgLight: 'bg-blue-50',
    borderLight: 'border-blue-200/60',
    prompt: 'How do fractions and common denominators work? Walk me through adding 2/3 and 3/4 step by step.',
    mode: 'problem',
  },
  {
    title: 'Physics & Nature',
    icon: Compass,
    color: 'text-indigo-600',
    bgLight: 'bg-indigo-50',
    borderLight: 'border-indigo-200/60',
    prompt: "Explain Newton's Three Laws of Motion with fun everyday examples.",
    mode: 'breakdown',
  },
  {
    title: 'World History',
    icon: Globe,
    color: 'text-amber-600',
    bgLight: 'bg-amber-50',
    borderLight: 'border-amber-200/60',
    prompt: 'Why did the Industrial Revolution start in Britain? Break down the top 4 causes.',
    mode: 'breakdown',
  },
  {
    title: 'Coding & Algorithms',
    icon: Code,
    color: 'text-violet-600',
    bgLight: 'bg-violet-50',
    borderLight: 'border-violet-200/60',
    prompt: 'What is a binary search algorithm and how does it work? Explain it like looking up a word in a dictionary.',
    mode: 'quick',
  },
  {
    title: 'Practice Quiz',
    icon: HelpCircle,
    color: 'text-rose-600',
    bgLight: 'bg-rose-50',
    borderLight: 'border-rose-200/60',
    prompt: 'Give me a 3-question beginner quiz on the Solar System and planets to test my knowledge.',
    mode: 'quiz',
  },
];

export const EmptyState: React.FC<EmptyStateProps> = ({ onSelectPrompt }) => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 sm:py-12">
      {/* Hero Header */}
      <div className="text-center mb-8 sm:mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/70 text-indigo-700 text-xs font-semibold mb-4 shadow-2xs">
          <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
          <span>Your Personal Study Companion</span>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
          Master any topic,{' '}
          <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            one clear step at a time.
          </span>
        </h1>

        <p className="mt-3 text-sm sm:text-base text-slate-600 max-w-xl mx-auto leading-relaxed">
          Stuck on homework, preparing for an exam, or learning something new? Ask anything — WisdomAI breaks complex topics into friendly, digestible explanations.
        </p>

        {/* Value pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 mt-5 text-xs text-slate-600">
          <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Step-by-step breakdowns</span>
          </div>
          <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
            <span>Intuitive everyday analogies</span>
          </div>
          <div className="flex items-center gap-1.5 bg-white px-3 py-1 rounded-full border border-slate-200/80 shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
            <span>Zero-judgment tutoring</span>
          </div>
        </div>
      </div>

      {/* Suggested prompts section */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
            Choose a topic or prompt to start
          </h2>
          <span className="text-[11px] text-slate-400">Click to ask instantly</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {STARTER_SUBJECTS.map((subject, idx) => {
            const Icon = subject.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectPrompt(subject.prompt, subject.mode)}
                className={`group text-left p-3.5 sm:p-4 rounded-xl bg-white hover:bg-slate-50/80 border ${subject.borderLight} hover:border-indigo-300 shadow-xs hover:shadow-sm transition-all duration-200 flex flex-col justify-between cursor-pointer`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-lg ${subject.bgLight} ${subject.color} flex items-center justify-center`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="font-semibold text-xs sm:text-sm text-slate-800">
                        {subject.title}
                      </span>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 px-1.5 py-0.5 rounded bg-slate-100">
                      {subject.mode}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-snug line-clamp-2">
                    "{subject.prompt}"
                  </p>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-end text-xs font-medium text-indigo-600 group-hover:text-indigo-700">
                  <span className="flex items-center gap-1 group-hover:gap-1.5 transition-all">
                    Ask this <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Beginner hint box */}
      <div className="mt-8 p-4 rounded-xl bg-gradient-to-r from-indigo-50/70 via-purple-50/40 to-amber-50/70 border border-indigo-100/80 text-center sm:text-left flex flex-col sm:flex-row items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-white shadow-xs border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
          <Zap className="w-5 h-5" />
        </div>
        <div className="text-xs text-slate-700 leading-relaxed">
          <span className="font-bold text-slate-900">Student Study Tip:</span> You can type anything like{' '}
          <span className="bg-white/90 px-1.5 py-0.5 rounded text-indigo-700 font-medium border border-indigo-200/50">"Explain gravity like I'm 10"</span> or paste any textbook question to see it solved step-by-step!
        </div>
      </div>
    </div>
  );
};
