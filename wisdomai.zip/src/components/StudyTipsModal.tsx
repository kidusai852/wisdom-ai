import React from 'react';
import { X, Lightbulb, Brain, Target, Repeat, HelpCircle, CheckCircle } from 'lucide-react';

interface StudyTipsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyPrompt: (prompt: string) => void;
}

export const StudyTipsModal: React.FC<StudyTipsModalProps> = ({
  isOpen,
  onClose,
  onApplyPrompt,
}) => {
  if (!isOpen) return null;

  const TIPS = [
    {
      title: 'The Feynman Technique',
      icon: Brain,
      color: 'text-indigo-600 bg-indigo-50 border-indigo-200',
      description:
        'Try to explain the concept in plain English as if explaining to a 10-year-old. When you get stuck, that reveals your knowledge gap.',
      examplePrompt: 'Explain this concept like I am 10 years old with a fun analogy.',
    },
    {
      title: 'Active Recall Testing',
      icon: HelpCircle,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
      description:
        'Reading notes passively is slow. Instead, test yourself with practice questions right after learning a concept.',
      examplePrompt: 'Give me 3 practice quiz questions on this topic to test my memory.',
    },
    {
      title: 'Avoid "The Illusion of Competence"',
      icon: Target,
      color: 'text-amber-600 bg-amber-50 border-amber-200',
      description:
        'Understanding an answer when you read it is easy; reproducing it from scratch is real mastery. Ask WisdomAI for a similar problem to solve on your own.',
      examplePrompt: 'Can you give me a similar problem without the answer so I can try solving it myself?',
    },
    {
      title: 'Identify Common Mistakes',
      icon: Repeat,
      color: 'text-rose-600 bg-rose-50 border-rose-200',
      description:
        'Knowing what pitfalls to watch out for helps you avoid losing points on exams and assignments.',
      examplePrompt: 'What are the top 3 common mistakes students make with this topic and how can I avoid them?',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div 
        className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 border border-amber-200/60 flex items-center justify-center">
              <Lightbulb className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Effective Study Strategies</h2>
              <p className="text-xs text-slate-500">Evidence-based learning tips to boost retention</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="p-4 sm:p-6 space-y-4">
          {TIPS.map((tip, idx) => {
            const Icon = tip.icon;
            return (
              <div
                key={idx}
                className="p-3.5 sm:p-4 rounded-xl border border-slate-200/90 bg-slate-50/50 hover:bg-white hover:border-indigo-200 transition-all flex flex-col gap-2"
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center border ${tip.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{tip.title}</h3>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed pl-9">
                  {tip.description}
                </p>

                <div className="pl-9 pt-1">
                  <button
                    onClick={() => {
                      onApplyPrompt(tip.examplePrompt);
                      onClose();
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-indigo-600 hover:text-indigo-800 font-semibold group cursor-pointer"
                  >
                    <span>Try prompt: "{tip.examplePrompt}"</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-lg shadow-2xs hover:bg-slate-50 cursor-pointer"
          >
            Got it, let's study!
          </button>
        </div>
      </div>
    </div>
  );
};
