import React, { useRef, useEffect } from 'react';
import { Send, Square, Sparkles, CornerDownLeft } from 'lucide-react';

interface ChatInputProps {
  input: string;
  setInput: (value: string) => void;
  onSend: (text?: string) => void;
  isLoading: boolean;
  onStop: () => void;
  hasMessages: boolean;
}

const QUICK_PROMPT_PILLS = [
  'Explain step-by-step',
  'Give a real-world analogy',
  'Test me with a quiz question',
  'Summarize in 3 bullet points',
  'Break down the math formula',
];

export const ChatInput: React.FC<ChatInputProps> = ({
  input,
  setInput,
  onSend,
  isLoading,
  onStop,
  hasMessages,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      // Cap at ~150px
      textareaRef.current.style.height = `${Math.min(scrollHeight, 150)}px`;
    }
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading && input.trim()) {
        onSend();
      }
    }
  };

  const handlePillClick = (pillText: string) => {
    if (input.trim()) {
      onSend(`${input.trim()} (${pillText})`);
    } else {
      setInput(`${pillText}: `);
      textareaRef.current?.focus();
    }
  };

  return (
    <div className="sticky bottom-0 bg-gradient-to-t from-slate-50 via-slate-50/95 to-slate-50/20 pt-3 pb-3 sm:pb-5 px-3 sm:px-6 z-20">
      <div className="max-w-4xl mx-auto">
        {/* Quick prompt pills if there is active conversation */}
        {hasMessages && !isLoading && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs">
            <span className="text-[11px] font-semibold text-slate-400 shrink-0 flex items-center gap-1 mr-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              Quick:
            </span>
            {QUICK_PROMPT_PILLS.map((pill, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handlePillClick(pill)}
                className="shrink-0 px-2.5 py-1 rounded-full bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-700 text-xs font-medium border border-slate-200 hover:border-indigo-300 shadow-2xs transition-colors cursor-pointer"
              >
                {pill}
              </button>
            ))}
          </div>
        )}

        {/* Input Card Container */}
        <div className="relative bg-white rounded-2xl border border-slate-300/80 shadow-md focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-100 transition-all p-2 sm:p-2.5 flex flex-col gap-1.5">
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask WisdomAI any question, paste homework, or ask to explain a concept step-by-step..."
            disabled={isLoading}
            className="w-full bg-transparent resize-none border-0 text-slate-900 placeholder-slate-400 text-sm sm:text-[15px] focus:outline-none px-2 py-1.5 min-h-[38px] max-h-[150px] leading-relaxed"
          />

          {/* Bottom Bar inside input card */}
          <div className="flex items-center justify-between pt-1 border-t border-slate-100 px-1 text-xs">
            <div className="text-[11px] text-slate-400 hidden sm:flex items-center gap-1">
              <span>Press</span>
              <kbd className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 font-mono text-[10px]">
                Enter ↵
              </kbd>
              <span>to send,</span>
              <kbd className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 font-mono text-[10px]">
                Shift + Enter
              </kbd>
              <span>for new line</span>
            </div>

            <div className="text-[11px] text-slate-400 sm:hidden">
              WisdomAI Tutor
            </div>

            <div className="flex items-center gap-2 ml-auto">
              {isLoading ? (
                <button
                  type="button"
                  onClick={onStop}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-medium text-xs shadow-xs transition-colors cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onSend()}
                  disabled={!input.trim()}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-semibold text-xs sm:text-sm shadow-xs transition-all cursor-pointer ${
                    input.trim()
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                  title="Send message"
                >
                  <span>Send</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Friendly footer disclaimer */}
        <p className="text-center text-[11px] text-slate-400 mt-2">
          WisdomAI is your learning assistant. Verify critical exam facts with your teacher or textbooks.
        </p>
      </div>
    </div>
  );
};
