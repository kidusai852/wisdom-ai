import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  GraduationCap, 
  User, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  RotateCcw,
  Sparkles,
  HelpCircle,
  Lightbulb,
  ListPlus
} from 'lucide-react';
import { ChatMessage, StudyMode } from '../types.ts';

interface MessageItemProps {
  message: ChatMessage;
  onQuickFollowUp: (text: string) => void;
  onRegenerate?: () => void;
  isLastAssistant: boolean;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  onQuickFollowUp,
  onRegenerate,
  isLastAssistant,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const isUser = message.role === 'user';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReadAloud = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported by your browser.');
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel(); // reset any ongoing speech
    // Clean markdown symbols for cleaner voice reading
    const cleanText = message.content
      .replace(/[#*`_~>[\]()]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isUser) {
    return (
      <div className="flex justify-end mb-6 group">
        <div className="flex items-start gap-2 max-w-[88%] sm:max-w-[75%] flex-row-reverse">
          {/* Student Avatar */}
          <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-xs ring-2 ring-slate-100">
            <User className="w-4 h-4 text-slate-200" />
          </div>

          <div>
            <div className="bg-indigo-600 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 shadow-xs text-sm sm:text-[15px] leading-relaxed break-words whitespace-pre-wrap">
              {message.content}
            </div>
            <div className="text-[10px] text-slate-400 mt-1 text-right pr-1">
              {formatTime(message.timestamp)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Assistant / WisdomAI Message
  return (
    <div className="flex justify-start mb-6 group">
      <div className="flex items-start gap-2.5 sm:gap-3.5 max-w-full sm:max-w-[94%]">
        {/* WisdomAI Avatar */}
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-amber-400 text-white flex items-center justify-center shrink-0 shadow-xs ring-2 ring-indigo-50">
          <GraduationCap className="w-5 h-5" />
        </div>

        <div className="flex-1 min-w-0">
          {/* Header Info */}
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="font-bold text-xs sm:text-sm text-slate-900 tracking-tight flex items-center gap-1">
              WisdomAI
            </span>
            <span className="inline-flex items-center px-1.5 py-0.2 text-[10px] font-semibold bg-indigo-50 text-indigo-700 rounded border border-indigo-200/60">
              Study Assistant
            </span>
            {message.studyMode && (
              <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded">
                {message.studyMode}
              </span>
            )}
            <span className="text-[10px] text-slate-400 ml-auto">
              {formatTime(message.timestamp)}
            </span>
          </div>

          {/* Assistant Message Bubble */}
          <div className="bg-white rounded-2xl rounded-tl-sm p-4 sm:p-5 shadow-xs border border-slate-200/80 text-slate-800 text-sm sm:text-[15px] leading-relaxed">
            <div className="markdown-body">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {message.content}
              </ReactMarkdown>
            </div>

            {/* Streaming Indicator */}
            {message.isStreaming && (
              <div className="flex items-center gap-1.5 text-xs text-indigo-600 font-medium mt-3 pt-2 border-t border-slate-100">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                <span>Explaining step-by-step...</span>
              </div>
            )}
          </div>

          {/* Action Toolbar */}
          {!message.isStreaming && (
            <div className="flex flex-wrap items-center gap-1.5 mt-2 pt-0.5">
              {/* Copy */}
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2 py-1 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                title="Copy response to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[11px] font-medium">{copied ? 'Copied' : 'Copy'}</span>
              </button>

              {/* Read Aloud */}
              <button
                onClick={handleReadAloud}
                className={`inline-flex items-center gap-1 px-2 py-1 text-xs rounded-md transition-colors cursor-pointer ${
                  isSpeaking
                    ? 'text-indigo-700 bg-indigo-50 border border-indigo-200 font-medium'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                }`}
                title={isSpeaking ? 'Stop reading' : 'Read explanation aloud'}
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-indigo-600" /> : <Volume2 className="w-3.5 h-3.5" />}
                <span className="text-[11px]">{isSpeaking ? 'Stop Audio' : 'Listen'}</span>
              </button>

              {/* Regenerate for last response */}
              {isLastAssistant && onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="inline-flex items-center gap-1 px-2 py-1 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                  title="Try generating this explanation again"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="text-[11px]">Retry</span>
                </button>
              )}

              {/* Quick follow-up chips */}
              <div className="w-full sm:w-auto flex flex-wrap items-center gap-1.5 mt-1 sm:mt-0 sm:ml-auto">
                <button
                  onClick={() => onQuickFollowUp('Can you explain this in even simpler terms with a friendly everyday analogy?')}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-indigo-700 bg-indigo-50/80 hover:bg-indigo-100 rounded-md border border-indigo-200/50 transition-colors cursor-pointer"
                >
                  <Lightbulb className="w-3 h-3 text-indigo-600" />
                  <span>Explain simpler</span>
                </button>

                <button
                  onClick={() => onQuickFollowUp('Can you test my understanding with 1 quick quiz question on this?')}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-emerald-700 bg-emerald-50/80 hover:bg-emerald-100 rounded-md border border-emerald-200/50 transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3 h-3 text-emerald-600" />
                  <span>Quiz me</span>
                </button>

                <button
                  onClick={() => onQuickFollowUp('Can you provide another concrete real-world example?')}
                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-amber-700 bg-amber-50/80 hover:bg-amber-100 rounded-md border border-amber-200/50 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>Another example</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
