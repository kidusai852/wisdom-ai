import React from 'react';
import { 
  GraduationCap, 
  Menu, 
  PlusCircle, 
  Download, 
  Lightbulb, 
  Sparkles,
  ChevronDown,
  Layers,
  Zap,
  HelpCircle,
  Calculator,
  BookMarked
} from 'lucide-react';
import { StudyMode, StudentLevel } from '../types.ts';

interface HeaderProps {
  studyMode: StudyMode;
  setStudyMode: (mode: StudyMode) => void;
  studentLevel: StudentLevel;
  setStudentLevel: (level: StudentLevel) => void;
  onNewSession: () => void;
  onExportNotes: () => void;
  onOpenTips: () => void;
  toggleSidebar: () => void;
  hasMessages: boolean;
}

export const STUDY_MODES: { id: StudyMode; label: string; icon: React.ComponentType<{ className?: string }>; description: string }[] = [
  { 
    id: 'breakdown', 
    label: 'Step-by-Step', 
    icon: Layers, 
    description: 'Detailed, methodical breakdown with analogies' 
  },
  { 
    id: 'quick', 
    label: 'Quick Explainer', 
    icon: Zap, 
    description: 'Bite-sized high level overview' 
  },
  { 
    id: 'quiz', 
    label: 'Practice Quiz', 
    icon: HelpCircle, 
    description: 'Test your understanding with practice questions' 
  },
  { 
    id: 'problem', 
    label: 'Problem Solver', 
    icon: Calculator, 
    description: 'Guided homework & calculation steps' 
  },
  { 
    id: 'flashcards', 
    label: 'Flashcards', 
    icon: BookMarked, 
    description: 'Key terms, definitions, and memory hooks' 
  },
];

export const Header: React.FC<HeaderProps> = ({
  studyMode,
  setStudyMode,
  studentLevel,
  setStudentLevel,
  onNewSession,
  onExportNotes,
  onOpenTips,
  toggleSidebar,
  hasMessages,
}) => {
  const [modeDropdownOpen, setModeDropdownOpen] = React.useState(false);
  const currentModeInfo = STUDY_MODES.find(m => m.id === studyMode) || STUDY_MODES[0];
  const CurrentIcon = currentModeInfo.icon;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Left: Menu button + Brand */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={toggleSidebar}
            aria-label="Toggle sessions sidebar"
            className="p-2 -ml-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-amber-400 flex items-center justify-center text-white shadow-sm ring-2 ring-indigo-100">
              <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-900 flex items-center gap-1">
                  Wisdom<span className="text-indigo-600">AI</span>
                </span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 text-[10px] font-semibold bg-indigo-50 text-indigo-700 rounded-full border border-indigo-200/60">
                  <Sparkles className="w-3 h-3 mr-0.5 text-amber-500" />
                  Study Tutor
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block -mt-0.5">
                Clear answers & step-by-step learning
              </p>
            </div>
          </div>
        </div>

        {/* Center / Right controls */}
        <div className="flex items-center gap-1.5 sm:gap-3">
          {/* Study Mode Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setModeDropdownOpen(!modeDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs sm:text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-lg border border-slate-200 transition-colors cursor-pointer"
              title="Change teaching style / study mode"
            >
              <CurrentIcon className="w-4 h-4 text-indigo-600" />
              <span className="font-semibold text-slate-800 hidden xs:inline">{currentModeInfo.label}</span>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-500 transition-transform ${modeDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {modeDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setModeDropdownOpen(false)} 
                />
                <div className="absolute right-0 sm:left-0 sm:right-auto mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                  <div className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                    Teaching & Study Mode
                  </div>
                  {STUDY_MODES.map((mode) => {
                    const ModeIcon = mode.icon;
                    const isActive = mode.id === studyMode;
                    return (
                      <button
                        key={mode.id}
                        onClick={() => {
                          setStudyMode(mode.id);
                          setModeDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 flex items-start gap-2.5 hover:bg-indigo-50/60 transition-colors cursor-pointer ${
                          isActive ? 'bg-indigo-50/80 text-indigo-900 font-medium' : 'text-slate-700'
                        }`}
                      >
                        <ModeIcon className={`w-4 h-4 mt-0.5 shrink-0 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                        <div>
                          <div className="text-xs font-semibold flex items-center gap-1.5">
                            {mode.label}
                            {isActive && <span className="w-1.5 h-1.5 rounded-full bg-indigo-600" />}
                          </div>
                          <div className="text-[11px] text-slate-500 font-normal leading-snug">
                            {mode.description}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </>
            )}
          </div>

          {/* Student Level selector */}
          <div className="hidden lg:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            {(['Beginner', 'Intermediate', 'Advanced'] as StudentLevel[]).map((level) => (
              <button
                key={level}
                onClick={() => setStudentLevel(level)}
                className={`px-2 py-1 text-xs rounded-md font-medium transition-all cursor-pointer ${
                  studentLevel === level
                    ? 'bg-white text-indigo-700 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title={`Explanations tailored for ${level} level`}
              >
                {level}
              </button>
            ))}
          </div>

          {/* Mobile Level Dropdown */}
          <div className="lg:hidden">
            <select
              value={studentLevel}
              onChange={(e) => setStudentLevel(e.target.value as StudentLevel)}
              className="text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Study Tips Button */}
          <button
            onClick={onOpenTips}
            className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200/70 transition-colors flex items-center gap-1 cursor-pointer"
            title="Study tips & strategies"
          >
            <Lightbulb className="w-4 h-4 text-amber-600" />
            <span className="hidden sm:inline font-medium">Tips</span>
          </button>

          {/* Export Notes (active if messages exist) */}
          {hasMessages && (
            <button
              onClick={onExportNotes}
              className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors flex items-center gap-1 cursor-pointer"
              title="Download chat as study notes"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline font-medium">Export</span>
            </button>
          )}

          {/* New Chat Button */}
          <button
            onClick={onNewSession}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs hover:shadow transition-all cursor-pointer"
            title="Start a new study session"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">New Topic</span>
          </button>
        </div>
      </div>
    </header>
  );
};
