import React, { useState } from 'react';
import { 
  X, 
  MessageSquare, 
  Plus, 
  Trash2, 
  BookOpen, 
  Search, 
  Sparkles,
  Layers,
  HelpCircle,
  Calculator,
  Zap,
  BookMarked
} from 'lucide-react';
import { StudySession, StudyMode } from '../types.ts';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: StudySession[];
  currentSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
}

const MODE_ICON_MAP: Record<StudyMode, React.ComponentType<{ className?: string }>> = {
  breakdown: Layers,
  quick: Zap,
  quiz: HelpCircle,
  problem: Calculator,
  flashcards: BookMarked,
};

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onClearAll,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSessions = sessions.filter((s) =>
    s.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-72 sm:w-80 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:w-0 lg:hidden'
        }`}
      >
        {/* Top Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight">Study Sessions</h2>
              <p className="text-[11px] text-slate-400">{sessions.length} saved topic{sessions.length === 1 ? '' : 's'}</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={onNewSession}
              aria-label="New session"
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Start a new study topic"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              aria-label="Close sidebar"
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors lg:hidden cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search bar */}
        {sessions.length > 2 && (
          <div className="px-3 pt-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>
        )}

        {/* Session List */}
        <div className="flex-1 overflow-y-auto px-2 py-3 space-y-1">
          {filteredSessions.length === 0 ? (
            <div className="text-center py-10 px-4 text-slate-400">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40 text-indigo-400" />
              <p className="text-xs font-medium text-slate-300">No study topics yet</p>
              <p className="text-[11px] text-slate-500 mt-1">
                Ask a question or pick an example to begin your study journey!
              </p>
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isSelected = session.id === currentSessionId;
              const ModeIcon = MODE_ICON_MAP[session.studyMode] || Layers;

              return (
                <div
                  key={session.id}
                  className={`group relative flex items-center justify-between rounded-lg px-3 py-2 text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600/30 text-white border border-indigo-500/40'
                      : 'text-slate-300 hover:bg-slate-800/80 hover:text-white border border-transparent'
                  }`}
                  onClick={() => onSelectSession(session.id)}
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-6">
                    <ModeIcon className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`} />
                    <div className="truncate">
                      <div className="font-medium truncate">{session.title}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                        <span>{new Date(session.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                        <span>•</span>
                        <span className="capitalize">{session.studentLevel}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    aria-label="Delete session"
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-400 hover:bg-slate-700/60 rounded transition-all cursor-pointer"
                    title="Delete session"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Bottom footer / learning badge */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5 text-indigo-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-semibold">WisdomAI Study Hub</span>
            </div>
            {sessions.length > 0 && (
              <button
                onClick={onClearAll}
                className="text-[11px] text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                title="Clear all saved sessions"
              >
                Clear all
              </button>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
