import React, { useState, useEffect, useRef } from 'react';
import { 
  Header, 
  STUDY_MODES 
} from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { EmptyState } from './components/EmptyState.tsx';
import { MessageItem } from './components/MessageItem.tsx';
import { ChatInput } from './components/ChatInput.tsx';
import { StudyTipsModal } from './components/StudyTipsModal.tsx';
import { ChatMessage, StudySession, StudyMode, StudentLevel } from './types.ts';
import { ArrowDown, AlertCircle } from 'lucide-react';

const STORAGE_KEY = 'wisdomai_study_sessions_v1';

export default function App() {
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [studyMode, setStudyMode] = useState<StudyMode>('breakdown');
  const [studentLevel, setStudentLevel] = useState<StudentLevel>('Beginner');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isTipsModalOpen, setIsTipsModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Initialize sessions from localStorage or create a fresh one
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setSessions(parsed);
          setCurrentSessionId(parsed[0].id);
          setStudyMode(parsed[0].studyMode || 'breakdown');
          setStudentLevel(parsed[0].studentLevel || 'Beginner');
          return;
        }
      }
    } catch (e) {
      console.error('Failed to load study sessions from localStorage', e);
    }

    // Default new session
    createNewSession();
  }, []);

  // Save sessions to localStorage
  useEffect(() => {
    if (sessions.length > 0) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
      } catch (e) {
        console.error('Failed to save sessions to localStorage', e);
      }
    }
  }, [sessions]);

  // Current session object
  const currentSession = sessions.find((s) => s.id === currentSessionId);
  const currentMessages = currentSession?.messages || [];

  // Auto-scroll logic
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    scrollToBottom('smooth');
  }, [currentMessages.length, isLoading]);

  // Handle scroll events to show/hide "jump to bottom" button
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottom(distanceToBottom > 160);
  };

  const createNewSession = (initialMode: StudyMode = studyMode) => {
    if (isLoading && abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }

    const newId = `session_${Date.now()}`;
    const newSession: StudySession = {
      id: newId,
      title: 'New Study Topic',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      studyMode: initialMode,
      studentLevel: studentLevel,
    };

    setSessions((prev) => [newSession, ...prev]);
    setCurrentSessionId(newId);
    setStudyMode(initialMode);
    setErrorMessage(null);
    setInput('');
  };

  const handleSelectSession = (id: string) => {
    if (isLoading && abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
    const session = sessions.find((s) => s.id === id);
    if (session) {
      setCurrentSessionId(id);
      setStudyMode(session.studyMode || 'breakdown');
      setStudentLevel(session.studentLevel || 'Beginner');
      setErrorMessage(null);
      // Close sidebar on mobile
      setIsSidebarOpen(false);
    }
  };

  const handleDeleteSession = (id: string) => {
    const remaining = sessions.filter((s) => s.id !== id);
    setSessions(remaining);
    if (currentSessionId === id) {
      if (remaining.length > 0) {
        setCurrentSessionId(remaining[0].id);
        setStudyMode(remaining[0].studyMode);
        setStudentLevel(remaining[0].studentLevel);
      } else {
        createNewSession();
      }
    }
  };

  const handleClearAllSessions = () => {
    if (window.confirm('Are you sure you want to clear all your saved study topics?')) {
      localStorage.removeItem(STORAGE_KEY);
      const newId = `session_${Date.now()}`;
      const freshSession: StudySession = {
        id: newId,
        title: 'New Study Topic',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        studyMode: 'breakdown',
        studentLevel: 'Beginner',
      };
      setSessions([freshSession]);
      setCurrentSessionId(newId);
    }
  };

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || isLoading) return;

    setErrorMessage(null);
    setInput('');

    const userMessage: ChatMessage = {
      id: `user_${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: Date.now(),
    };

    const assistantPlaceholderId = `assistant_${Date.now() + 1}`;
    const assistantPlaceholder: ChatMessage = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: Date.now() + 1,
      studyMode: studyMode,
      isStreaming: true,
    };

    const updatedMessages = [...currentMessages, userMessage];

    // Auto-update session title if it's the first user message
    let sessionTitle = currentSession?.title;
    if (currentMessages.length === 0 || currentSession?.title === 'New Study Topic') {
      sessionTitle = textToSend.slice(0, 32) + (textToSend.length > 32 ? '...' : '');
    }

    // Update session state with user message and placeholder
    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSessionId
          ? {
              ...s,
              title: sessionTitle || s.title,
              updatedAt: Date.now(),
              messages: [...updatedMessages, assistantPlaceholder],
              studyMode,
              studentLevel,
            }
          : s
      )
    );

    setIsLoading(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          studyMode,
          studentLevel,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported by browser or empty response');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedResponse = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.replace('data: ', '').trim();
            if (dataStr === '[DONE]') {
              continue;
            }
            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                accumulatedResponse += parsed.text;
                // Update active assistant message in session
                setSessions((prev) =>
                  prev.map((s) =>
                    s.id === currentSessionId
                      ? {
                          ...s,
                          messages: s.messages.map((m) =>
                            m.id === assistantPlaceholderId
                              ? { ...m, content: accumulatedResponse, isStreaming: true }
                              : m
                          ),
                        }
                      : s
                  )
                );
              } else if (parsed.error) {
                throw new Error(parsed.error);
              }
            } catch (err) {
              // Non-fatal parse error of SSE line
            }
          }
        }
      }

      // Mark streaming as complete
      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSessionId
            ? {
                ...s,
                messages: s.messages.map((m) =>
                  m.id === assistantPlaceholderId
                    ? { ...m, isStreaming: false }
                    : m
                ),
              }
            : s
        )
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User aborted intentionally
        setSessions((prev) =>
          prev.map((s) =>
            s.id === currentSessionId
              ? {
                  ...s,
                  messages: s.messages.map((m) =>
                    m.id === assistantPlaceholderId
                      ? { ...m, isStreaming: false, content: m.content || '(Explanation stopped by student)' }
                      : m
                  ),
                }
              : s
          )
        );
      } else {
        console.error('Chat error:', err);
        const errorText = err.message || 'Something went wrong while connecting to WisdomAI.';
        setErrorMessage(errorText);

        setSessions((prev) =>
          prev.map((s) =>
            s.id === currentSessionId
              ? {
                  ...s,
                  messages: s.messages.map((m) =>
                    m.id === assistantPlaceholderId
                      ? {
                          ...m,
                          isStreaming: false,
                          content: `⚠️ **Unable to complete explanation:**\n\n${errorText}\n\n*Please ensure your Gemini API key is configured or try asking again.*`,
                        }
                      : m
                  ),
                }
              : s
          )
        );
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoading(false);
  };

  const handleRegenerate = () => {
    if (currentMessages.length === 0 || isLoading) return;
    // Find the last user message
    const lastUserIdx = [...currentMessages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIdx === -1) return;

    const actualIdx = currentMessages.length - 1 - lastUserIdx;
    const lastUserMsg = currentMessages[actualIdx];

    // Remove the last assistant message
    const trimmed = currentMessages.slice(0, actualIdx);
    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSessionId ? { ...s, messages: trimmed } : s
      )
    );

    // Re-send
    handleSendMessage(lastUserMsg.content);
  };

  const handleExportNotes = () => {
    if (currentMessages.length === 0) return;

    const title = currentSession?.title || 'WisdomAI Study Notes';
    const dateStr = new Date().toLocaleDateString([], {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    let markdown = `# ${title}\n`;
    markdown += `**WisdomAI Study Assistant Notes** • ${dateStr}\n`;
    markdown += `**Study Mode**: ${studyMode} | **Level**: ${studentLevel}\n\n`;
    markdown += `---\n\n`;

    currentMessages.forEach((msg, idx) => {
      if (msg.role === 'user') {
        markdown += `### ❓ Student Question (${new Date(msg.timestamp).toLocaleTimeString()}):\n`;
        markdown += `${msg.content}\n\n`;
      } else {
        markdown += `### 💡 WisdomAI Explanation:\n`;
        markdown += `${msg.content}\n\n`;
        markdown += `---\n\n`;
      }
    });

    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-study-notes.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 text-slate-800">
      {/* Sessions Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={() => {
          createNewSession();
          setIsSidebarOpen(false);
        }}
        onDeleteSession={handleDeleteSession}
        onClearAll={handleClearAllSessions}
      />

      {/* Main Study Experience Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full relative">
        {/* Top Header */}
        <Header
          studyMode={studyMode}
          setStudyMode={(mode) => {
            setStudyMode(mode);
            setSessions((prev) =>
              prev.map((s) => (s.id === currentSessionId ? { ...s, studyMode: mode } : s))
            );
          }}
          studentLevel={studentLevel}
          setStudentLevel={(level) => {
            setStudentLevel(level);
            setSessions((prev) =>
              prev.map((s) => (s.id === currentSessionId ? { ...s, studentLevel: level } : s))
            );
          }}
          onNewSession={() => createNewSession()}
          onExportNotes={handleExportNotes}
          onOpenTips={() => setIsTipsModalOpen(true)}
          toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          hasMessages={currentMessages.length > 0}
        />

        {/* Global Error Banner if any */}
        {errorMessage && (
          <div className="bg-red-50 border-b border-red-200 px-4 py-2.5 flex items-center justify-between text-xs text-red-800">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-600 hover:text-red-900 font-semibold text-xs ml-4"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Conversation / Content Area */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-3 sm:px-6 pt-4 pb-4 scroll-smooth"
        >
          {currentMessages.length === 0 ? (
            <EmptyState
              onSelectPrompt={(prompt, mode) => {
                if (mode) {
                  setStudyMode(mode);
                }
                handleSendMessage(prompt);
              }}
            />
          ) : (
            <div className="max-w-4xl mx-auto py-2">
              {currentMessages.map((message, index) => {
                const isLastAssistant =
                  message.role === 'assistant' &&
                  index === currentMessages.length - 1;

                return (
                  <MessageItem
                    key={message.id}
                    message={message}
                    onQuickFollowUp={(followUpText) => handleSendMessage(followUpText)}
                    onRegenerate={isLastAssistant ? handleRegenerate : undefined}
                    isLastAssistant={isLastAssistant}
                  />
                );
              })}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          )}
        </div>

        {/* Floating "Scroll to bottom" button */}
        {showScrollBottom && (
          <button
            onClick={() => scrollToBottom('smooth')}
            className="absolute bottom-28 right-6 z-30 p-2.5 rounded-full bg-white text-indigo-600 shadow-lg border border-slate-200 hover:bg-slate-50 transition-all cursor-pointer"
            title="Scroll to latest message"
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        )}

        {/* Bottom Chat Input Box */}
        <ChatInput
          input={input}
          setInput={setInput}
          onSend={(customText) => handleSendMessage(customText)}
          isLoading={isLoading}
          onStop={handleStop}
          hasMessages={currentMessages.length > 0}
        />
      </div>

      {/* Study Tips & Strategies Modal */}
      <StudyTipsModal
        isOpen={isTipsModalOpen}
        onClose={() => setIsTipsModalOpen(false)}
        onApplyPrompt={(prompt) => {
          setInput(prompt);
        }}
      />
    </div>
  );
}
