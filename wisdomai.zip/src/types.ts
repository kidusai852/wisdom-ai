export type StudyMode = 'breakdown' | 'quick' | 'quiz' | 'problem' | 'flashcards';

export type StudentLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  studyMode?: StudyMode;
  isStreaming?: boolean;
}

export interface StudySession {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  studyMode: StudyMode;
  studentLevel: StudentLevel;
}
