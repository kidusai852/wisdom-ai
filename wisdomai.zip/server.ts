import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialise Gemini with User-Agent header for AI Studio telemetry
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Chat endpoint supporting streaming (Server-Sent Events)
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, studyMode = 'breakdown', studentLevel = 'Beginner' } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please check your environment variables.',
      });
    }

    let modeInstruction = '';
    switch (studyMode) {
      case 'breakdown':
        modeInstruction = `MODE: Step-by-Step Breakdown (Beginner Friendly)
- Break complex ideas down into numbered steps (e.g. "### Step 1: ...", "### Step 2: ...").
- Give an everyday analogy that makes the concept click intuitively.
- Keep the language clear, welcoming, and easy to read.
- Conclude with a helpful "💡 Key Takeaway" and an interactive "🤔 Check for Understanding" question.`;
        break;
      case 'quick':
        modeInstruction = `MODE: Quick Concept Explainer
- Provide a brief, punchy overview (2-3 short paragraphs).
- Include 1 clear real-world analogy.
- Provide a bulleted "3-Point Cheat Sheet".`;
        break;
      case 'quiz':
        modeInstruction = `MODE: Practice Quizzer
- Test the student on this topic with 2-3 engaging multiple-choice or short conceptual questions.
- Provide clear options (A, B, C, D) and hide the explanation/answer under a spoiler or ask the student to pick one before revealing.
- If the student has already answered a quiz question in their message, evaluate their answer gently and explain the right logic step by step!`;
        break;
      case 'problem':
        modeInstruction = `MODE: Homework & Problem Solver
- Don't just dump the answer! Walk through the methodology step by step.
- State the Given Information, the Formula/Core Concept needed, Step-by-Step Calculation/Reasoning, and the Final Verification.
- Encourage the student at each phase.`;
        break;
      case 'flashcards':
        modeInstruction = `MODE: Flashcards & Key Terms
- Present 4-6 high-yield key terms/concepts related to the topic.
- Format each as a card with:
  **Term / Concept**: [Name]
  **Simple Definition**: [Plain english explanation]
  **Memory Hook / Tip**: [Mnemonic or visual trick to remember it]`;
        break;
      default:
        modeInstruction = `MODE: Step-by-Step Study Assistant
- Answer questions clearly, break difficult ideas down into steps, and use relatable examples.`;
    }

    const levelDetails = {
      Beginner: 'Explain in simple, welcoming terms suitable for middle/high school or someone brand new to the subject. Avoid unnecessary jargon, or define it with friendly analogies.',
      Intermediate: 'Balanced depth suitable for high school or early undergrad. Clear explanations with standard terminology and conceptual depth.',
      Advanced: 'Thorough, academic rigor with formal definitions, edge cases, and deeper theoretical context while remaining clear and structured.',
    }[studentLevel as 'Beginner' | 'Intermediate' | 'Advanced'] || 'Explain in clear, friendly beginner-accessible terms.';

    const systemInstruction = `You are WisdomAI, a warm, supportive, and exceptionally clear AI study assistant designed to help students learn and succeed.
Your motto: "Every difficult concept becomes simple when broken down the right way."

STUDENT LEVEL: ${studentLevel} (${levelDetails})
${modeInstruction}

FORMATTING & TEACHING RULES:
1. Always be encouraging, patient, and motivating.
2. Structure your answers cleanly using Markdown:
   - Use headings (##, ###) for major sections.
   - Use numbered steps when explaining processes, algorithms, or problem solving.
   - Use bold text for key terms and vocabulary.
   - Use bullet points for lists and comparisons.
   - Use blockquotes (> ...) for pro-tips, caution notes, or memorable summaries.
   - Use code blocks or math notation where appropriate.
3. If a question is ambiguous, provide the most likely answer first and politely ask if they meant something specific.
4. Keep paragraphs readable and avoid massive walls of dense text.
5. Never mock or make the student feel bad for asking a simple question. Foster curiosity!`;

    // Filter and format Gemini contents
    const contents = messages
      .filter((m: any) => m && typeof m.content === 'string' && m.content.trim().length > 0)
      .map((m: any) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));

    if (contents.length === 0) {
      return res.status(400).json({ error: 'No valid message content provided' });
    }

    // Set SSE headers
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');

    const modelsToTry = [
      'gemini-3.1-flash-lite',
      'gemini-flash-lite-latest',
      'gemini-3.8-flash',
      'gemini-flash-latest',
    ];
    let succeeded = false;
    let lastError: any = null;

    for (const modelName of modelsToTry) {
      try {
        const responseStream = await ai.models.generateContentStream({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        for await (const chunk of responseStream) {
          if (chunk.text) {
            res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
          }
        }

        succeeded = true;
        break;
      } catch (err: any) {
        lastError = err;
        console.warn(`Model ${modelName} stream error, attempting fallback:`, err?.message || err);
      }
    }

    if (!succeeded) {
      throw lastError || new Error('All AI models are currently experiencing high demand. Please try again in a moment.');
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: error.message || 'Error communicating with Gemini' });
    } else {
      res.write(`data: ${JSON.stringify({ error: error.message || 'Generation interrupted' })}\n\n`);
      res.end();
    }
  }
});

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    app: 'WisdomAI',
    hasKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

async function start() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WisdomAI server running at http://0.0.0.0:${PORT}`);
  });
}

start();
